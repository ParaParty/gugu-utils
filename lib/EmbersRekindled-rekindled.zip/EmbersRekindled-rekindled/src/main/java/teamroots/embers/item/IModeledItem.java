package teamroots.embers.item;

public interface IModeledItem {
	public void initModel();
}
