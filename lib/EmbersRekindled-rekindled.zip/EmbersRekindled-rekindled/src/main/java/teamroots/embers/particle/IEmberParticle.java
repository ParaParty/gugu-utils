package teamroots.embers.particle;

public interface IEmberParticle {
	public boolean alive();
	public boolean isAdditive();
	public boolean renderThroughBlocks();
}
