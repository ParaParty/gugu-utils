package teamroots.embers.api.item;

public interface IProjectileWeapon {
}
