package teamroots.embers.itemmod;

@Deprecated
public class ModifierProjectileBase extends teamroots.embers.api.itemmod.ModifierProjectileBase {
    public ModifierProjectileBase(String name, double cost, boolean levelCounts) {
        super(name, cost, levelCounts);
    }
}
