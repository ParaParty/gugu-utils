package teamroots.embers.block;

public interface IModeledBlock {
	public void initModel();
}
