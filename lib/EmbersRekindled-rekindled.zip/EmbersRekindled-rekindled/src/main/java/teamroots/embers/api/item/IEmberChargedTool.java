package teamroots.embers.api.item;

import net.minecraft.item.ItemStack;

public interface IEmberChargedTool {
	boolean hasEmber(ItemStack stack);
}
