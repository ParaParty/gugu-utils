package teamroots.embers.api.item;

public interface IHeldEmberCell {

}
