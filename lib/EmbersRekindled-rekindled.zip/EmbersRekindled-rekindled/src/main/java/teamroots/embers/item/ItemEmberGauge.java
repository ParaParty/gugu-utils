package teamroots.embers.item;

public class ItemEmberGauge extends ItemBase {

	public ItemEmberGauge() {
		super("ember_detector", true);
		this.setMaxStackSize(1);
	}
}
