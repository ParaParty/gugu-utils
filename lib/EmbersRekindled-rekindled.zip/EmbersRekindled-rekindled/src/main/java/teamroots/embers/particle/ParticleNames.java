package teamroots.embers.particle;

public class ParticleNames {
	public static final String NAME_PARTICLE_GLOW = "glow";
}
