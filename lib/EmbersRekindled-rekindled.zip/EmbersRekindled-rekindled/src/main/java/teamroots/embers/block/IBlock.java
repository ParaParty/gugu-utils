package teamroots.embers.block;

import net.minecraft.item.Item;

public interface IBlock {
	public Item getItemBlock();
}
