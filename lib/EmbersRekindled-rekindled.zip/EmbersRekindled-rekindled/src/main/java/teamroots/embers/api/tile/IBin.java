package teamroots.embers.api.tile;

import net.minecraftforge.items.IItemHandler;

public interface IBin {
    IItemHandler getInventory();
}
