package teamroots.embers.api.item;

public interface IInventoryEmberCell {

}
