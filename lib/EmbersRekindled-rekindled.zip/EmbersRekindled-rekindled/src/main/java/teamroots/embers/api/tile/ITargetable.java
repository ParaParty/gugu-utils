package teamroots.embers.api.tile;

import net.minecraft.util.math.BlockPos;

public interface ITargetable {
	void setTarget(BlockPos pos);
}
