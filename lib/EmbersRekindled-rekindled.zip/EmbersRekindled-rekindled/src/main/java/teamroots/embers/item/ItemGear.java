package teamroots.embers.item;

public class ItemGear extends ItemBase {
	public ItemGear(String name, boolean addToTab) {
		super(name, addToTab);
	}
}
