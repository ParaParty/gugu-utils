package thaumcraft.api.golems.seals;

/**
 * This class identifies this seal as using the default area configuration options.
 */
public interface ISealConfigArea {
	
}
