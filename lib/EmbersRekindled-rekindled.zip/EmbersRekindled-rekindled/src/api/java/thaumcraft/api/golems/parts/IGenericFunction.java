package thaumcraft.api.golems.parts;

import thaumcraft.api.golems.IGolemAPI;

public interface IGenericFunction {
	public void onUpdateTick(IGolemAPI golem);
}
