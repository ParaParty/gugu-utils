#### Issue Description:
Note: If this bug occurs in a modpack, please report this to the modpack author. Otherwise, delete this line and add your description here. If this is a feature request, this template does not apply to you. Just delete everything.


#### What happens:



#### What you expected to happen:



#### Steps to reproduce:

1. 
2. 
3. 
...

____
#### Affected Versions (Do *not* use "latest"):

- BloodMagic: 
- Minecraft: 
- Forge: 