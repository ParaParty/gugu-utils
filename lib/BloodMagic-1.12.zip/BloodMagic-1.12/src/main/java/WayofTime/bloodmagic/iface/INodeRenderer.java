package WayofTime.bloodmagic.iface;

/**
 * Held items that implement this will cause the beams between routing nodes to
 * render.
 */
public interface INodeRenderer {
}
