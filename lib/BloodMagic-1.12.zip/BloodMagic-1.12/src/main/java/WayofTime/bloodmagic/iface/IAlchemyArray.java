package WayofTime.bloodmagic.iface;

import net.minecraft.util.EnumFacing;

public interface IAlchemyArray {
    EnumFacing getRotation();
}
