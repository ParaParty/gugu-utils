package WayofTime.bloodmagic.incense;

public enum EnumTranquilityType {
    PLANT(),
    CROP(),
    TREE(),
    EARTHEN(),
    WATER(),
    FIRE(),
    LAVA(),
    ;
}
