package WayofTime.bloodmagic.block;

import net.minecraft.item.ItemBlock;

public interface IBMBlock {

    ItemBlock getItem();
}
