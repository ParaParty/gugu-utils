package WayofTime.bloodmagic.altar;

/**
 * Any item that implements this interface will not be pulled into the Altar on
 * right click.
 */
public interface IAltarManipulator {
}
