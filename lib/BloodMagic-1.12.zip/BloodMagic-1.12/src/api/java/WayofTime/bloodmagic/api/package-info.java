@API(owner = "bloodmagic", provides = "bloodmagic-api", apiVersion = "2.0.0")
package WayofTime.bloodmagic.api;

import net.minecraftforge.fml.common.API;